﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.tweetapp.Service
{
    interface IUserIntro
    {
        public void WelcomeConsole();
        public void IntroPageNonLoggedUser();
        public bool UserRegistration();




    }
}
