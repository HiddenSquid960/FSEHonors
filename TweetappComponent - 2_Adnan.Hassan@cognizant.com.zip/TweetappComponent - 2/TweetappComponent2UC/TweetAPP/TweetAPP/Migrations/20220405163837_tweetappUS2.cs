﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TweetAPP.Migrations
{
    public partial class tweetappUS2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
