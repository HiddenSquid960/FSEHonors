import { RegisteredUser } from './registered-user';

describe('RegisteredUser', () => {
  it('should create an instance', () => {
    expect(new RegisteredUser()).toBeTruthy();
  });
});
