export class Tweet {
    public id:number;
    public userid: number;
    public tweets:string;
    public username: string;
    public lastName: string;
    public firstName: string;
    public tweetDate:Date;
    public likes:number;
}
